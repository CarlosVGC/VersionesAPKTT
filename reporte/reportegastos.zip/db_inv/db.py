import os   # Paquete para las funciones que requieren recursos del OS
import sqlite3 # biblioteca de la base de datos

APP_PATH = os.getcwd() # obtiene la dirección donde se úbican los archivos .py y .kv
DB_PATH = APP_PATH+'/prueba.db' # crea la base de datos

def conexion_database(path):
    try:
        con = sqlite3.connect(path)
        cursor = con.cursor()
        crea_tabla_producto(cursor)


        con.commit()
        con.close()
    except Exception as e:
        print(e)
#
############# Creamos las tablas en la base de datos #############
#
def crea_tabla_producto(cursor):
    cursor.execute(comando2)


# Tabla productos #
comando2 = """ CREATE TABLE IF NOT EXISTS
PRODUCTOS(
    ID       INT PRIMARY KEY NOT NULL,
    NOMBRE   TEXT            NOT NULL,
    PRECIO   FLOAT             NOT NULL,
    CANTIDAD INT             NOT NULL,
    FECHA    DATETIME            NOT NULL  
)   """