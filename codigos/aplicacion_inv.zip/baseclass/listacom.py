from kivy.uix.screenmanager import Screen
from kivymd.app import MDApp

class ListaC(Screen):
    pass
