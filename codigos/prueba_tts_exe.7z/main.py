# -*- coding: utf-8 -*-
import kivy
kivy.require('1.8.0')

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
   
from plyer import tts
import speech_recognition as sr


class Principal(BoxLayout):
    
    def presiona_boton_producto(self):
        r= sr.Recognizer()
        
        try:
            tts.speak('Producto')
            #print ("Escuchando")
            with sr.Microphone() as source:
                print("Hable ahora...")
                audio = r.listen(source)
                
                texto = r.recognize_google(audio, language='es-ES')
                self.ids.txt_producto.text = texto
            
        except NotImplementedError:
            popup = ErrorPopup()
            popup.open()
        except:
            print("No entendí o tardó demasiado")
            
    def presiona_boton_cantidad(self):
        r= sr.Recognizer()
        
        try:
            tts.speak('Cantidad')
            #print ("Escuchando")
            with sr.Microphone() as source:
                print("Hable ahora...")
                audio = r.listen(source)
                
                texto = r.recognize_google(audio, language='es-ES')
                self.ids.txt_cantidad.text = texto
           
        except NotImplementedError:
            popup = ErrorPopup()
            popup.open()
        except:
            print("No entendí o tardó demasiado")
                
    
    def presiona_boton_precio(self):
        r= sr.Recognizer()
        
        try:
            tts.speak('Precio')
            #print ("Escuchando")
            with sr.Microphone() as source:
                print("Hable ahora...")
                audio = r.listen(source)
                
                texto = r.recognize_google(audio, language='es-ES')
                self.ids.txt_precio.text = texto
           
        except NotImplementedError:
            popup = ErrorPopup()
            popup.open()
        except:
            print("No entendí o tardó demasiado")
                
        


class IPVApp(App):
    def build(self):
        return Principal()

    def on_pause(self):
        return True


class ErrorPopup(Popup):
    pass

if __name__ == '__main__':
    IPVApp().run()
